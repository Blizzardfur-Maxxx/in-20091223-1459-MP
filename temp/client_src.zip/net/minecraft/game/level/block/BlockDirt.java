package net.minecraft.game.level.block;

public final class BlockDirt extends Block {
	protected BlockDirt() {
		super(3, 2);
	}
}
