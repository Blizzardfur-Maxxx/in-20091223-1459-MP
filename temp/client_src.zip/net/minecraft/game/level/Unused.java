package net.minecraft.game.level;

final class Unused {
}
