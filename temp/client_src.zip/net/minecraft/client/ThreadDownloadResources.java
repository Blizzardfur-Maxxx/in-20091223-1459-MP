package net.minecraft.client;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URL;

public final class ThreadDownloadResources extends Thread {
	private File resourcesFolder;
	boolean closing = false;

	public ThreadDownloadResources(File file1, Minecraft minecraft2) {
		this.setName("Resource download thread");
		this.setDaemon(true);
		this.resourcesFolder = new File(file1, "resources/");
		if(!this.resourcesFolder.exists() && !this.resourcesFolder.mkdirs()) {
			throw new RuntimeException("The working directory could not be created: " + this.resourcesFolder);
		}
	}

	public final void run() {
		// $FF: Couldn't be decompiled
	}

	private void downloadResource(URL uRL1, File file2) throws IOException {
		byte[] b3 = new byte[4096];
		DataInputStream dataInputStream5 = new DataInputStream(uRL1.openStream());
		DataOutputStream dataOutputStream6 = new DataOutputStream(new FileOutputStream(file2));
		boolean z4 = false;

		do {
			int i7;
			if((i7 = dataInputStream5.read(b3)) < 0) {
				dataInputStream5.close();
				dataOutputStream6.close();
				return;
			}

			dataOutputStream6.write(b3, 0, i7);
		} while(!this.closing);

	}
}
