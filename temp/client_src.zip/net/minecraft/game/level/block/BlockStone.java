package net.minecraft.game.level.block;

public final class BlockStone extends Block {
	public BlockStone(int i1, int i2) {
		super(i1, i2);
	}
}
