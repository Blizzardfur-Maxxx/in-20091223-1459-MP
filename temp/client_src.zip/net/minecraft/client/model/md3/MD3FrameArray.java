package net.minecraft.client.model.md3;

public final class MD3FrameArray {
}
