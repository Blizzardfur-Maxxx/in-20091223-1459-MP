package net.minecraft.client.model;

public abstract class ModelBase {
}
