package net.minecraft.client;

enum EnumOS {
	linux,
	solaris,
	windows,
	macos,
	unknown;

	public static EnumOS[] getOsList() {
		return (EnumOS[])osList.clone();
	}
}
