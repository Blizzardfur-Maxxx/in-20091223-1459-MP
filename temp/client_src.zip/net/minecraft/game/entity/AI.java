package net.minecraft.game.entity;

import net.minecraft.game.level.World;

public abstract class AI {
	public void onLivingUpdate(World world1, EntityLiving entityLiving2) {
	}
}
